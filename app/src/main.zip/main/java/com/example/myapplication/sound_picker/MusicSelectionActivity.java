package com.example.myapplication.sound_picker;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class MusicSelectionActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MusicAdapter musicAdapter;
    private List<Music> musicList;
    private ImageButton backButton;
    private Music selectedMusic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hien_thi_list_nhac);

        recyclerView = findViewById(R.id.list_view_music);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Dummy data, replace with actual music data
        musicList = new ArrayList<>();
        musicList.add(new Music(1, "Arpeggio", "", "uri1"));
        musicList.add(new Music(2, "Breaking", "", "uri2"));
        musicList.add(new Music(3, "Canopy", "", "uri3"));
        musicList.add(new Music(4, "Chalet", "", "uri4"));
        musicList.add(new Music(5, "Chirp", "", "uri5"));
        musicList.add(new Music(6, "Daybreak", "", "uri6"));


        musicAdapter = new MusicAdapter(musicList, music -> selectedMusic = music);
        recyclerView.setAdapter(musicAdapter);

        backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultIntent = new Intent();
                if (selectedMusic != null) {
                    resultIntent.putExtra("selected_music_uri", selectedMusic.getUri());
                    resultIntent.putExtra("selected_music_title", selectedMusic.getTitle());
                    resultIntent.putExtra("selected_music_artist", selectedMusic.getArtist());
                    setResult(RESULT_OK, resultIntent);
                }
                finish();
            }
        });
    }
}
