package com.example.myapplication.sound_picker;

public class Music {
    private long id;
    private String title;
    private String artist;
    private String uri;

    public Music(long id, String title, String artist, String uri) {
        this.id = id;
        this.title = title;
        this.artist = artist;
        this.uri = uri;
    }

    public long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }

    public String getUri() {
        return uri;
    }
}
